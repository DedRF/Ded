﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Privyazka
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Auth_Click(object sender, RoutedEventArgs e)
        {
            string con = "Server=stud-mssql.sttec.yar.ru,38325;Database=user108_db;User Id=user108_db;Password=user108;TrustServerCertificate=True;";
            try
            {
                using (SqlConnection conConnection = new SqlConnection(con))
                {
                    string command = "SELECT Login, Password, ID_Role FROM [Users] WHERE Login = @Login AND Password = @Password";

                    using (SqlCommand sqlCommand = new SqlCommand(command, conConnection))
                    {
                        sqlCommand.Parameters.AddWithValue("@Login", LoginTxt.Text);
                        sqlCommand.Parameters.AddWithValue("@Password", PassTxt.Password);

                        conConnection.Open();

                        using (SqlDataReader reader = sqlCommand.ExecuteReader())
                        {
                            string log = "";
                            string pass = "";
                            int role = 0;
                            bool userFound = false;

                            while (reader.Read())
                            {
                                log = reader.GetString(0);
                                pass = reader.GetString(1);
                                role = reader.GetInt32(2);
                                userFound = true;
                            }
                            if (userFound && LoginTxt.Text == log && PassTxt.Password == pass)
                            {
                                if (role == 1)
                                {
                                    MessageBox.Show("Авторизация успешна! Доступ: Администратор");
                                    // переход на главную форму администратора
                                    userControl userControl = new userControl();
                                    userControl.Show();
                                }
                                else if (role == 2)
                                {
                                    MessageBox.Show("Авторизация успешна! Доступ: Пользователь");
                                }
                                else
                                {
                                    MessageBox.Show("Авторизация успешна! Роль не определена");
                                }

                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}");
            }   
        }

        private void Regis_Click(object sender, RoutedEventArgs e)
        {
            if (Register.IsEnabled == true)
            {
                regWin regWin = new regWin();
                regWin.Show();
                this.Close();
            }
        }
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace Privyazka
{
    public partial class userControl : Window
    {
        public userControl()
        {
            InitializeComponent();
            this.Loaded += Window_Loaded;
        }

 
        string con = "Server=stud-mssql.sttec.yar.ru,38325;Database=user108_db;User Id=user108_db;Password=user108;TrustServerCertificate=True;";

        private DataTable dataTable;
        private SqlDataAdapter adapter;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitializeData();
        }

        private void InitializeData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                    string selectSql = "SELECT * FROM [Users]";
                    adapter = new SqlDataAdapter(selectSql, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
                    dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DG.ItemsSource = dataTable.DefaultView;

                    // Выводим сгенерированные команды для отладки
                    Console.WriteLine("Insert Command: " + commandBuilder.GetInsertCommand().CommandText);
                    Console.WriteLine("Update Command: " + commandBuilder.GetUpdateCommand().CommandText);
                    Console.WriteLine("Delete Command: " + commandBuilder.GetDeleteCommand().CommandText);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации: {ex.Message}\n\nДетали: {ex.InnerException?.Message}");
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtLogin.Text) ||
                    string.IsNullOrWhiteSpace(txtPassword.Text) ||
                    string.IsNullOrWhiteSpace(txtFamiliya.Text) ||
                    string.IsNullOrWhiteSpace(txtImya.Text))
                {
                    MessageBox.Show("Заполните обязательные поля: Логин, Пароль, Фамилия, Имя");
                    return;
                }
                if (!int.TryParse(txtRole.Text, out int roleId))
                {
                    MessageBox.Show("Роль должна быть числовым значением (ID роли)");
                    return;
                }

                DataRow newRow = dataTable.NewRow();

                // Заполняем поля в ТОЧНОМ соответствии со структурой таблицы
                newRow["Login"] = txtLogin.Text.Trim();
                newRow["Password"] = txtPassword.Text.Trim();
                newRow["ID_Role"] = roleId; // Используем числовое значение
                newRow["Familiya"] = txtFamiliya.Text.Trim();
                newRow["Imya"] = txtImya.Text.Trim();
                newRow["Otchestvo"] = string.IsNullOrWhiteSpace(txtOtchestvo.Text) ? DBNull.Value : (object)txtOtchestvo.Text.Trim();
                newRow["Passport"] = string.IsNullOrWhiteSpace(txtPassport.Text) ? DBNull.Value : (object)txtPassport.Text.Trim();
                newRow["Medicin_polis"] = string.IsNullOrWhiteSpace(txtMedPolis.Text) ? DBNull.Value : (object)txtMedPolis.Text.Trim();
                newRow["SNILS"] = string.IsNullOrWhiteSpace(txtSNILS.Text) ? DBNull.Value : (object)txtSNILS.Text.Trim();
                newRow["Data_Rozhdenia"] = dpDataRojdenie.SelectedDate ?? (object)DBNull.Value;

                dataTable.Rows.Add(newRow);

                adapter.Update(dataTable);

                MessageBox.Show("Запись добавлена");
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления: {ex.Message}\n\nДетали: {ex.InnerException?.Message}");
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (DG.SelectedItem == null)
            {
                MessageBox.Show("Выберите запись для редактирования");
                return;
            }

            try
            {
                // проверка роли (должно быть числом)
                if (!int.TryParse(txtRole.Text, out int roleId))
                {
                    MessageBox.Show("Роль должна быть числовым значением (ID роли)");
                    return;
                }

                DataRowView selectedRow = (DataRowView)DG.SelectedItem;

                selectedRow.BeginEdit();
                selectedRow["Login"] = txtLogin.Text.Trim();
                selectedRow["Password"] = txtPassword.Text.Trim();
                selectedRow["ID_Role"] = roleId;
                selectedRow["Familiya"] = txtFamiliya.Text.Trim();
                selectedRow["Imya"] = txtImya.Text.Trim();
                selectedRow["Otchestvo"] = string.IsNullOrWhiteSpace(txtOtchestvo.Text) ? DBNull.Value : (object)txtOtchestvo.Text.Trim();
                selectedRow["Passport"] = string.IsNullOrWhiteSpace(txtPassport.Text) ? DBNull.Value : (object)txtPassport.Text.Trim();
                selectedRow["Medicin_polis"] = string.IsNullOrWhiteSpace(txtMedPolis.Text) ? DBNull.Value : (object)txtMedPolis.Text.Trim();
                selectedRow["SNILS"] = string.IsNullOrWhiteSpace(txtSNILS.Text) ? DBNull.Value : (object)txtSNILS.Text.Trim();
                selectedRow["Data_Rozhdenia"] = dpDataRojdenie.SelectedDate ?? (object)DBNull.Value;
                selectedRow.EndEdit();

                // обновление бд
                adapter.Update(dataTable);

                MessageBox.Show("Запись обновлена");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка редактирования: {ex.Message}\n\nДетали: {ex.InnerException?.Message}");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (DG.SelectedItem == null)
            {
                MessageBox.Show("Выберите запись для удаления");
                return;
            }

            try
            {
                DataRowView selectedRow = (DataRowView)DG.SelectedItem;
                selectedRow.Row.Delete();

                // обновление бд
                adapter.Update(dataTable);

                MessageBox.Show("Запись удалена");
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}\n\nДетали: {ex.InnerException?.Message}");
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearForm();
        }

        private void RefreshData()
        {
            try
            {
                dataTable.Clear();
                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                    adapter.SelectCommand.Connection = connection;
                    adapter.Fill(dataTable);
                }
                MessageBox.Show("Данные обновлены");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления: {ex.Message}");
            }
        }

        private void ClearForm()
        {
            txtFamiliya.Clear();
            txtImya.Clear();
            txtOtchestvo.Clear();
            dpDataRojdenie.SelectedDate = null;
            txtPassport.Clear();
            txtMedPolis.Clear();
            txtSNILS.Clear();
            txtLogin.Clear();
            txtPassword.Clear();
            txtRole.Clear();
        }

        private void DG_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DG.SelectedItem != null)
            {
                DataRowView row = (DataRowView)DG.SelectedItem;

                txtLogin.Text = row["Login"]?.ToString() ?? "";
                txtPassword.Text = row["Password"]?.ToString() ?? "";
                txtRole.Text = row["ID_Role"]?.ToString() ?? "";
                txtFamiliya.Text = row["Familiya"]?.ToString() ?? "";
                txtImya.Text = row["Imya"]?.ToString() ?? "";
                txtOtchestvo.Text = row["Otchestvo"]?.ToString() ?? "";
                txtPassport.Text = row["Passport"]?.ToString() ?? "";
                txtMedPolis.Text = row["Medicin_polis"]?.ToString() ?? "";
                txtSNILS.Text = row["SNILS"]?.ToString() ?? "";
                if (row["Data_Rozhdenia"] != DBNull.Value)
                    dpDataRojdenie.SelectedDate = Convert.ToDateTime(row["Data_Rozhdenia"]);
            }
        }

        private void txtLogin_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
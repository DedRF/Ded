﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Privyazka
{
    public partial class regWin : Window
    {
        private bool isUpdatingPassword = false;

        public regWin()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            // проверка на заполнение обязательных полей
            if (string.IsNullOrWhiteSpace(LoginBox.Text))
            {
                MessageBox.Show("Введите логин!");
                LoginBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                MessageBox.Show("Введите пароль!");
                PasswordBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Familya.Text))
            {
                MessageBox.Show("Введите фамилию!");
                Familya.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Imya.Text))
            {
                MessageBox.Show("Введите имя!");
                Imya.Focus();
                return;
            }
            // проверка минимальной длины пароля
            if (PasswordBox.Password.Length < 6)
            {
                MessageBox.Show("Пароль должен содержать минимум 6 символов!");
                PasswordBox.Focus();
                return;
            }
            string con = "Server=stud-mssql.sttec.yar.ru,38325;Database=user108_db;User Id=user108_db;Password=user108;TrustServerCertificate=True;";

            try
            {
                //  проверка существует ли уже пользователь с таким логином
                string checkLoginCommand = "SELECT COUNT(*) FROM [Users] WHERE Login = @Login";

                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();

                    // Проверка существующего логина
                    using (SqlCommand checkCommand = new SqlCommand(checkLoginCommand, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Login", LoginBox.Text.Trim());
                        int existingUsers = (int)checkCommand.ExecuteScalar();

                        if (existingUsers > 0)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует!");
                            LoginBox.Focus();
                            return;
                        }
                    }

                    // SQL запрос для вставки данных (исправленный - убрал @Role)
                    string insertCommand = @"INSERT INTO [Users] (Login, Password, ID_Role, Familya, Imya, Otchestvo) 
                                           VALUES (@Login, @Password,@ID_Role, @Familya, @Imya, @Otchestvo)";

                    using (SqlCommand command = new SqlCommand(insertCommand, connection))
                    {
                        // Добавляем параметры 
                        command.Parameters.AddWithValue("@Login", LoginBox.Text.Trim());
                        command.Parameters.AddWithValue("@Password", PasswordBox.Password);
                        command.Parameters.AddWithValue("@ID_Role", 1);
                        command.Parameters.AddWithValue("@Familya", Familya.Text.Trim());
                        command.Parameters.AddWithValue("@Imya", Imya.Text.Trim());

                        // Обработка отчества (может быть null)
                        if (string.IsNullOrWhiteSpace(Otchestvo.Text))
                            command.Parameters.AddWithValue("@Otchestvo", DBNull.Value);
                        else
                            command.Parameters.AddWithValue("@Otchestvo", Otchestvo.Text.Trim());

                        // Выполняем запрос
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Регистрация прошла успешно!");

                            // ПЕРЕНАПРАВЛЕНИЕ НА ГЛАВНОЕ ОКНО
                            MainWindow mainWindow = new MainWindow();
                            mainWindow.Show();
                            this.Close(); // Закрываем окно регистрации
                        }
                        else
                        {
                            MessageBox.Show("Ошибка при регистрации");
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"Ошибка базы данных: {sqlEx.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка регистрации: {ex.Message}");
            }
        }

        private void ShowPassword_Checked(object sender, RoutedEventArgs e)
        {
            PasswordTextBox.Visibility = Visibility.Visible;
            PasswordBox.Visibility = Visibility.Collapsed;

            if (!isUpdatingPassword)
            {
                isUpdatingPassword = true;
                PasswordTextBox.Text = PasswordBox.Password;
                isUpdatingPassword = false;
            }
        }

        private void ShowPassword_Unchecked(object sender, RoutedEventArgs e)
        {
            PasswordBox.Visibility = Visibility.Visible;
            PasswordTextBox.Visibility = Visibility.Collapsed;

            if (!isUpdatingPassword)
            {
                isUpdatingPassword = true;
                PasswordBox.Password = PasswordTextBox.Text;
                isUpdatingPassword = false;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (!isUpdatingPassword && ShowPassword.IsChecked == true)
            {
                isUpdatingPassword = true;
                PasswordTextBox.Text = PasswordBox.Password;
                isUpdatingPassword = false;
            }
        }

        private void PasswordTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!isUpdatingPassword && ShowPassword.IsChecked == true)
            {
                isUpdatingPassword = true;
                PasswordBox.Password = PasswordTextBox.Text;
                isUpdatingPassword = false;
            }
        }

        private void backToLogin_Click(object sender, RoutedEventArgs e)
        {
            
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}